namespace AI.Cli.Commands;

internal sealed class MarkdownSchema
{
    public string Markdown { get; set; } = string.Empty;
}