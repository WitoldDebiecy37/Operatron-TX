namespace AI.Cli.Commands;

internal sealed class StringArraySchema
{
    public string[] Value { get; set; } = [];
}