namespace AI.Cli.Models;

internal enum Format
{
    Text,
    Lines,
    Json,
    Markdown,
    ConventionalCommit,
}