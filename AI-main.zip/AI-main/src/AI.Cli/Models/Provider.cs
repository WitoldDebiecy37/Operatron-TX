namespace AI.Cli.Models;

internal enum Provider
{
    Auto,
    OpenAi,
    OpenRouter,
    Anthropic,
    Free,
}