var searchData=
[
  ['favorites',['Favorites',['../enumcom_1_1amazon_1_1aace_1_1alexa_1_1_local_media_source_1_1_favorites.html',1,'com.amazon.aace.alexa.LocalMediaSource.Favorites'],['../enumcom_1_1amazon_1_1aace_1_1alexa_1_1_external_media_adapter_1_1_favorites.html',1,'com.amazon.aace.alexa.ExternalMediaAdapter.Favorites']]]
];
