var searchData=
[
  ['deviceconfigurationupdated',['deviceConfigurationUpdated',['../classcom_1_1amazon_1_1aace_1_1phonecontrol_1_1_phone_call_controller.html#ad7d3413ded20b937afc728931005c122',1,'com::amazon::aace::phonecontrol::PhoneCallController']]],
  ['dial',['dial',['../classcom_1_1amazon_1_1aace_1_1phonecontrol_1_1_phone_call_controller.html#a01d791710c2d299ca213b7723b593b0d',1,'com::amazon::aace::phonecontrol::PhoneCallController']]],
  ['dialogstatechanged',['dialogStateChanged',['../classcom_1_1amazon_1_1aace_1_1alexa_1_1_alexa_client.html#aa0c7e22aeb8007a30d02a0f89226886a',1,'com::amazon::aace::alexa::AlexaClient']]],
  ['disablewakeworddetection',['disableWakewordDetection',['../classcom_1_1amazon_1_1aace_1_1alexa_1_1_speech_recognizer.html#af4c4e11876474aa362c4a9d628f3c1b6',1,'com::amazon::aace::alexa::SpeechRecognizer']]]
];
