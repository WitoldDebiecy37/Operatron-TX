1. Download and extract Arena Linux exe.
2. Modify the paths in run_linux.sh and run it.