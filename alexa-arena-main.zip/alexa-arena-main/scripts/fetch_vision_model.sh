#!/bin/bash
# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: LGPL-2.1


aws s3 cp s3://alexa-arena-resources/model-artifacts/vision-model/21.pth $HOME/AlexaArena/logs/vision_model_checkpt/21.pth --no-sign-request
