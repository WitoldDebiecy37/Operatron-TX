#!/bin/bash
# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: LGPL-2.1


aws s3 cp s3://alexa-arena-resources/model-artifacts/vl-model/65.pth $HOME/AlexaArena/logs/vl_model_checkpt/65.pth --no-sign-request
