# External (non-OpenAI) Pull Request Requirements

Before opening this Pull Request, please read the "Contributing" section of the README or your PR may be closed:
https://github.com/openai/codex#contributing

If your PR conforms to our contribution guidelines, replace this text with a detailed and high quality description of your changes.
