# npm releases

Run the following:

To build the 0.2.x or later version of the npm module, which runs the Rust version of the CLI, build it as follows:

```bash
./codex-cli/scripts/stage_rust_release.py --release-version 0.6.0
```
