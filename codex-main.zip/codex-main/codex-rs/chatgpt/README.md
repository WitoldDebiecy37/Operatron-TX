# ChatGPT

This crate pertains to first party ChatGPT APIs and products such as Codex agent.

This crate should be primarily built and maintained by OpenAI employees. Please reach out to a maintainer before making an external contribution.
