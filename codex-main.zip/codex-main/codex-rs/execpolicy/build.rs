fn main() {
    println!("cargo:rerun-if-changed=src/default.policy");
}
