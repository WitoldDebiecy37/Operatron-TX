pub(crate) const DEFAULT_WRAP_COLS: u16 = 80;
