using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace OpenAI.Assistants;

[CodeGenType("AssistantObjectToolResourcesCodeInterpreter")]
[CodeGenVisibility(nameof(CodeInterpreterToolResources), CodeGenVisibility.Public)]
public partial class CodeInterpreterToolResources
{ }
