using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace OpenAI.Assistants;

[CodeGenType("FileSearchRankingOptions")]
[CodeGenVisibility(nameof(FileSearchRankingOptions), CodeGenVisibility.Internal)]
public partial class FileSearchRankingOptions
{ }
