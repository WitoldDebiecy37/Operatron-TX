﻿namespace OpenAI.Assistants;

[CodeGenType("UnknownAssistantToolDefinition")]
internal partial class UnknownAssistantToolDefinition
{
}