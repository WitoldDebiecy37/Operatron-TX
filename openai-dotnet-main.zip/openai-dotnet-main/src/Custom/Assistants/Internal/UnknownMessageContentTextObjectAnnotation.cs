﻿namespace OpenAI.Assistants;

[CodeGenType("UnknownMessageContentTextObjectAnnotation")]
internal partial class UnknownMessageContentTextObjectAnnotation
{
}