﻿namespace OpenAI.Assistants;

[CodeGenType("UnknownMessageDeltaContent")]
internal partial class UnknownMessageDeltaContent
{
}
