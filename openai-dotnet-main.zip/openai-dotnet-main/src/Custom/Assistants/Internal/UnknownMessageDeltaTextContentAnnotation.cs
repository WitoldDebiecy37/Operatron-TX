﻿namespace OpenAI.Assistants;

[CodeGenType("UnknownMessageDeltaTextContentAnnotation")]
internal partial class UnknownMessageDeltaTextContentAnnotation
{
}