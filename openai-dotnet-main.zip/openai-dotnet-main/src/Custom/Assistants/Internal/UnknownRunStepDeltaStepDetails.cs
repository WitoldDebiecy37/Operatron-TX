﻿namespace OpenAI.Assistants;

[CodeGenType("UnknownRunStepDeltaStepDetails")]
internal partial class UnknownRunStepDeltaStepDetails
{
}