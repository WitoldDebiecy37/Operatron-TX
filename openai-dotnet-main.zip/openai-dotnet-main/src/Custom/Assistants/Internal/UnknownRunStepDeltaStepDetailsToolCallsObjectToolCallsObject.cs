﻿namespace OpenAI.Assistants;

[CodeGenType("UnknownRunStepDeltaStepDetailsToolCallsObjectToolCallsObject")]
internal partial class UnknownRunStepDeltaStepDetailsToolCallsObjectToolCallsObject
{
}