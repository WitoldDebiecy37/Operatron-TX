﻿namespace OpenAI.Assistants;

[CodeGenType("UnknownRunStepDetails")]
internal partial class UnknownRunStepDetails
{
}