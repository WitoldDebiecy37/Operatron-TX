﻿namespace OpenAI.Assistants;

[CodeGenType("UnknownRunStepDetailsToolCallsObjectToolCallsObject")]
internal partial class UnknownRunStepDetailsToolCallsObjectToolCallsObject
{
}