﻿namespace OpenAI.Assistants;

[CodeGenType("UnknownRunStepObjectStepDetails")]
internal partial class UnknownRunStepObjectStepDetails
{
}