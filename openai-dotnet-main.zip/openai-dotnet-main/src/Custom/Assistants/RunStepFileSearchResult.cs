using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace OpenAI.Assistants;

[CodeGenType("RunStepDetailsToolCallsFileSearchResultObject")]
public partial class RunStepFileSearchResult
{
}
