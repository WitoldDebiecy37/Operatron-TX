﻿using System.Diagnostics.CodeAnalysis;

namespace OpenAI.Assistants;

// CUSTOM: Renamed.
[Experimental("OPENAI001")]
[CodeGenType("RunStepDetailsToolCallsFileSearchResultObjectContentType")]
public enum RunStepFileSearchResultContentKind
{
    Text,
}