using System.Diagnostics.CodeAnalysis;

namespace OpenAI.Audio;

// CUSTOM: Added Experimental attribute.
[CodeGenType("CreateTranscriptionResponseStreamEvent")]
public partial class StreamingAudioTranscriptionUpdate
{
}