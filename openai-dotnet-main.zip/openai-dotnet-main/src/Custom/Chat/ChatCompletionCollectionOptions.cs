namespace OpenAI.Chat;

// CUSTOM: Make public and use the correct namespace.
[CodeGenType("ChatCompletionCollectionOptions")] public partial class ChatCompletionCollectionOptions { }