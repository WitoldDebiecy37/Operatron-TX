namespace OpenAI.Chat;

// CUSTOM: Make public and use the correct namespace.
[CodeGenType("ChatCompletionCollectionOrder")] public readonly partial struct ChatCompletionCollectionOrder { }