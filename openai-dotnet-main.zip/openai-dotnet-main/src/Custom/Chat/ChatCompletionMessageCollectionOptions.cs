namespace OpenAI.Chat;

// CUSTOM: Use the correct namespace.
[CodeGenType("ChatCompletionMessageCollectionOptions")] 
public partial class ChatCompletionMessageCollectionOptions {}