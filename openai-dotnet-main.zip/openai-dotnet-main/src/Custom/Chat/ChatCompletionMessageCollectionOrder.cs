namespace OpenAI.Chat;

// CUSTOM: Use the correct namespace.
[CodeGenType("ChatCompletionMessageCollectionOrder")] 
public readonly partial struct ChatCompletionMessageCollectionOrder {}