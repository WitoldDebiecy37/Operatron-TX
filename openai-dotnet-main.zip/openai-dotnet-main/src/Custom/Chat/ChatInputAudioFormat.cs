using System.Diagnostics.CodeAnalysis;

namespace OpenAI.Chat;

// CUSTOM: Added Experimental attribute.
[CodeGenType("ChatCompletionRequestMessageContentPartAudioInputAudioFormat")]
public readonly partial struct ChatInputAudioFormat
{

}
