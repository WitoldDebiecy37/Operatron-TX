using System.Diagnostics.CodeAnalysis;

namespace OpenAI.Chat;

// CUSTOM: Added Experimental attribute.
[CodeGenType("ReasoningEffort")]
public readonly partial struct ChatReasoningEffortLevel
{
}