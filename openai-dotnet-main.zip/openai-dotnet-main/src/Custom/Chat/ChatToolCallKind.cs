namespace OpenAI.Chat;

[CodeGenType("ChatToolCallKind")]
public enum ChatToolCallKind
{
    Function,
}
