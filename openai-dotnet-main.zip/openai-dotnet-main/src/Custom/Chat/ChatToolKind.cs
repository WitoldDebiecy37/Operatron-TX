﻿namespace OpenAI.Chat;

[CodeGenType("ChatToolKind")]
public enum ChatToolKind
{
    Function,
}
