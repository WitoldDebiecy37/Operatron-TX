﻿namespace OpenAI.Chat;

[CodeGenType("DotNetChatResponseFormatJsonObject")]
internal partial class InternalDotNetChatResponseFormatJsonObject
{ }