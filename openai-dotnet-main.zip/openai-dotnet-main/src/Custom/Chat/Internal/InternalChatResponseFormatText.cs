﻿namespace OpenAI.Chat;

[CodeGenType("DotNetChatResponseFormatText")]
internal partial class InternalDotNetChatResponseFormatText
{ }