namespace OpenAI.Chat;

[CodeGenType("UnknownChatCompletionRequestMessage")]
internal partial class InternalUnknownChatMessage : ChatMessage
{

}