﻿namespace OpenAI.Chat;

[CodeGenType("UnknownDotNetChatResponseFormat")]
internal partial class InternalUnknownChatResponseFormat
{
}