using System.Diagnostics.CodeAnalysis;

namespace OpenAI.Assistants;

[CodeGenType("FileSearchRanker")]
public readonly partial struct FileSearchRanker
{
}
