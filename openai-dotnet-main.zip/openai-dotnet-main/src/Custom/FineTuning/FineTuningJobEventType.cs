using System.Diagnostics.CodeAnalysis;

namespace OpenAI.FineTuning;

[CodeGenType("FineTuningJobEventType")]
public readonly partial struct FineTuningJobEventKind
{
}
