using System.Diagnostics.CodeAnalysis;

namespace OpenAI.Images;

// CUSTOM:
// - Added Experimental attribute.
// - Renamed.

[CodeGenType("CreateImageRequestBackground")]
public readonly partial struct GeneratedImageBackground
{
}