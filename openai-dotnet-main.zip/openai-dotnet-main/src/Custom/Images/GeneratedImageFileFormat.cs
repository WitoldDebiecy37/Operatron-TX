using System.Diagnostics.CodeAnalysis;

namespace OpenAI.Images;

// CUSTOM:
// - Added Experimental attribute.
// - Renamed.

[CodeGenType("CreateImageRequestOutputFormat")]
public readonly partial struct GeneratedImageFileFormat
{
}