using System.Diagnostics.CodeAnalysis;

namespace OpenAI.Images;

// CUSTOM:
// - Added Experimental attribute.
// - Renamed.

[CodeGenType("CreateImageRequestModeration")]
public readonly partial struct GeneratedImageModerationLevel
{
}