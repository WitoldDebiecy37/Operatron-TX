namespace OpenAI;

[CodeGenType("CreateThreadAndRunRequestAccept")]
internal readonly partial struct AcceptHeaderValue { }
