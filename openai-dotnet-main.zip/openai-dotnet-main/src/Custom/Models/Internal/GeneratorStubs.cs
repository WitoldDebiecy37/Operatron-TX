
namespace OpenAI.Models;

[CodeGenType("DeleteModelResponseObject")]
internal readonly partial struct InternalDeleteModelResponseObject { }

[CodeGenType("ListModelsResponseObject")]
internal readonly partial struct InternalListModelsResponseObject { }

[CodeGenType("ModelObject")]
internal readonly partial struct InternalModelObject { }
