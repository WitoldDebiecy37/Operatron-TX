namespace OpenAI;

[CodeGenType("OpenAIModelFactory")]
internal static partial class OpenAIModelFactory
{
}
