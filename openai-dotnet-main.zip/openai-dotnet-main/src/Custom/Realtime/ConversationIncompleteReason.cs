using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace OpenAI.Realtime;

[CodeGenType("RealtimeResponseStatusDetailsReason")]
public readonly partial struct ConversationIncompleteReason
{
}